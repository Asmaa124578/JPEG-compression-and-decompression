package http;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        String stream;
        Scanner input = new Scanner (System.in);
        System.out.println("Enter the sequence of numbers : ");
        stream = input.nextLine();
        int cntr=0;
        int count=0;
        char num;
        for(int i=0; i<stream.length(); i++){
            if (stream.charAt(i) == '0'){
                cntr++;
                i++;

                if(stream.charAt(i) !='0'){
                    count= cntr;
                    cntr=0;

                }
            }
            else if (stream.charAt(i) != '0'){
                 num = stream.charAt(i);
                 if(stream.charAt(i) == '0'){

                 }
            }
            System.out.println("+++++++"+ count +  "/" +stream.charAt(i) );
        }


    }
}
